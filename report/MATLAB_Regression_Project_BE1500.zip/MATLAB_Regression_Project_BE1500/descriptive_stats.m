function descriptive_stats(data)
cases=data.new_cases(1:min(length(data.new_cases),2500));
total=0;
max_cases=-Inf;
min_cases=Inf;
val_count=0;
for i= 1:length(cases)
    if ~isnan(cases(i)) && cases(i) ~=0
    total=total+cases(i);
    val_count= val_count+1;
    if cases(i)>max_cases
        max_cases=cases(i);
    end 
    if cases(i)<min_cases
        min_cases=cases(i);
    end 
    end 
end 
if val_count>0
meancases=total./val_count;
else 
    meancases = NaN ;
end 
if val_count > 0
    range_cases = max_cases- min_cases;
else 
    range_cases = NaN
end 
disp('---Descriptive Statistics---')
fprintf('Total New Cases: %0.2f\n',total)
fprintf('Mean New Cases: %0.2f\n', meancases)
fprintf('Max New Cases: %0.2f\n', max_cases)
fprintf('Min New Cases: %0.2f\n', min_cases)
fprintf('Range of New Cases: %0.2f\n', range_cases);
end 
function visualize_results(data)
cases=data.new_cases(1:2500);
deaths=data.new_deaths(1:2500);
days=1:2500;
%2D
figure;
plot(days,cases,'r-','LineWidth',1.5);
title('New COVID-19 Cases Over Time')
xlabel('Days')
ylabel('New Cases');
grid on
%bar
figure;
bar(days,deaths,'Facecolor','r')
title('New COVID-19 Deaths Over Time')
xlabel('Days');
ylabel('New Deaths');
grid on;
%3D
figure;
scatter3(cases,deaths,days,'filled');
title('3D Scattar Plot: Cases vs Deaths');
xlabel('New Cases');
ylabel('New Deaths');
zlabel('Days');
grid on;
end 

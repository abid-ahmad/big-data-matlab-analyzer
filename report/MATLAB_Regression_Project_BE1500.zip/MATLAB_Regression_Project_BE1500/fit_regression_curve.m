function fit_regression_curve(data)
cases=data.new_cases (1:2500);
days=1:2500;
p=polyfit(days, cases,1);
yfit=polyval(p,days);
figure;
plot(days,cases,'b-','LineWidth',1.5);
hold on
plot(days,yfit,'r--','LineWidth',2);
title('COVID-19 Cases with Linear Fit');
xlabel('Days')
ylabel('New Cases');
legend('Actual Data', 'Linear Fit')
grid on
axis tight
ylim([min(cases)-10, max(cases)]);
end 

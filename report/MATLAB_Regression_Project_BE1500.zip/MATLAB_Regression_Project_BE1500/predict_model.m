function predict_model(data)
cases=data.new_cases(1:2500);
deaths=data.new_deaths(1:2500);
totalcase=0;
totaldeath=0;
validdays=0;
day=1;
while day <=2500
    if ~isnan(cases(day))&& ~isnan(deaths(day))
        totalcase=totalcase+cases(day);
        totaldeath=totaldeath+deaths(day);
        validdays=validdays+1;
    end 
    day=day+1;
  if validdays >0
      avg_cases=totalcase/validdays;
      avg_deaths=totaldeath/validdays;
  else 
         avg_cases=NaN;
      avg_deaths=NaN;
  end 
end 
disp('---Trend Prediction---')
fprintf('Average New Cases (Overall): %0.2f\n', avg_cases)
fprintf('Predicted New Cases (Next Day): %0.2f\n', avg_cases)
fprintf('Average New Deaths (Overall): %0.2f\n', avg_deaths)
fprintf('Average New Deaths (Next Day): %0.2f\n', avg_deaths)
data=readtable("covid_dataset.csv");
disp('Data loaded sucessfully.')
data_1=data(1:2500,:);
choice=0;
while choice ~=5
disp('---COVID-19 DATA---');
disp('1.View Descriptive Statistics');
disp('2.Predict Data');
disp('3.Visualize Data');
disp('4.Fit a curve');
disp('5.Exit');
choice=input('Enter your selection: ');
if choice==1
   descriptive_stats(data)
elseif choice==2
    predict_model(data);
elseif choice==3
        visualize_results(data);
elseif choice==4
    fit_regression_curve(data)
elseif choice==5
    disp('Exiting');
else 
    disp('Invalid input. Try Again.')
end 
end 